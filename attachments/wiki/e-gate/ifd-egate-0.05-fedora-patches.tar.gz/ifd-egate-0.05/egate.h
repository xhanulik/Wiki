#ifndef _ETOKEN_H
#define _ETOKEN_H

#include <sys/types.h>

#define MAX_TOKENS 16

struct egate {
	struct usb_dev_handle *usb;
	char *dirname;
	char *filename;
	int lun;
	int atrlen;
	char atr[256];
        unsigned char stat;
};

/* egate.c */
int power_up_egate(struct egate *egate);
int power_down_egate(struct egate *egate);
RESPONSECODE egate_probe(struct egate *egate);
RESPONSECODE egate_get_usb(struct egate *egate);
int egate_release_usb(struct egate *egate);
struct egate * egate_get_token_by_lun(DWORD Lun);



void hexdump(const u_int8_t * data, int length);
RESPONSECODE usb_transfer(struct egate *egate, u_int8_t * buffer_out,
		 u_int8_t * buffer_in, int len_out, int *len_int);

#endif				/* _ETOKEN_H */
